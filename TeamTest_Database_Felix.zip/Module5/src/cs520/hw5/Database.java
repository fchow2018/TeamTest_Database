package cs520.hw5;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	private static final String URL = "jdbc:mysql://metcs520.mysql.database.azure.com:3306/chowf";
	private static final String USERNAME = "chowf@metcs520";
	private static final String PASSWORD = "metcs520";

	public void insertPlayers(Collection<Player> players) {
			Connection conn = null;
			try {
			conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);

			for (int i = 0; i < 10; i++) {
				String query = "delete from players where number = 20";
				Statement stmt = conn.createStatement();
				stmt.executeUpdate(query);
				String name = null;
				int number = 0;
				String pos = null;
				String year = null;
//				query = "insert into players values (" + number + ", " + "'" + name + "'" + ","  + "'" + pos + "'" + ", " + "'" + year + "'" + ")";
//				query = "insert into players values (number, 'name', 'position', 'year')";
				query = "insert into players values (20, 'Joe Smith', 'PG', 'Senior')";
				stmt.executeUpdate(query);
				System.out.print(toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	finally {
			try {
				if (conn != null) {
					conn.close();
				}
			}
			catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public Map selectPlayers() {
		
		Connection conn = null;
		
		try {
			HashMap <String, Player> players = new HashMap<String, Player>();
			conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from players");

			while (rs.next()) {
				Player player = null;
				player.setNumber(rs.getInt("NUMBER"));
				player.setName(rs.getString("NAME"));
				player.setPosition(rs.getString("POSITION"));
				player.setYear(rs.getString("YEAR"));
			
			}

			//			return players;

		} catch (Exception e) {
			Map players = null;
			return players;
//			e.printStackTrace();
//			Map players = null;
//			return players;
		}	finally {
			try {
				if (conn != null) {
					conn.close();
				}
			}
			catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null; 

	}
}




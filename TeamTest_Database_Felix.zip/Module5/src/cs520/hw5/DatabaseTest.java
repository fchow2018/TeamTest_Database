package cs520.hw5;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Iterator;
import java.util.Scanner;

public class DatabaseTest {
	public static Player createPlayer(String number, String name, String position, String year) {
		int num = Integer.parseInt(number);

		Player player = new Player(name);
		player.setNumber(num);
		player.setName(name);
		player.setPosition(position);
		player.setYear(year);		
		return player;

	}

	public static void main(String[] args) {

		LinkedHashSet<Player> players = new LinkedHashSet<Player>();

		try {
			File file = new File("D:\\FelixImportantSchoolDocuments\\1_BostonUniversityOnlineMastersOfDataManagement\\AllClasses\\CS520_O2InformationStructuresWithJava\\Assignments\\Module3\\src\\cs520\\hw3\\part2\\team.txt");
			Scanner scanner = new Scanner(file);
			int playerCount = 0;
			while (scanner.hasNextLine()) {
				String uniformNumber = scanner.nextLine();
				String name = scanner.nextLine();
				String position = scanner.nextLine();
				String year = scanner.nextLine();
				if (scanner.hasNextLine()) {
					scanner.nextLine();
				}
				playerCount++;
			}
			
			scanner.close();
			
			Database database = new Database();
			database.insertPlayers(players);
			Object selectPlayers = database.selectPlayers();
			
			Iterator<Player> itr = players.iterator();
			
//			for (int i = 0; i < selectedPlayers(); i++) {
			while (itr.hasNext()) {
				Player player = itr.next();
				System.out.print(((Map) players).put(player.getName(), player));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
